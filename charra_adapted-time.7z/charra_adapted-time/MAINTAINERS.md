Michael Eckel <michael.eckel@sit.fraunhofer.de>
